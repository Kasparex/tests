
use num_bigint::{ BigInt, BigUint, Sign as BigSign };
use num_traits::ToPrimitive;

include!{"util.rs"}
include!{"hashrate.rs"}

