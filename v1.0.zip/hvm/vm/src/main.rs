
include!{"lib.rs"}

pub fn main() {

    testexec::do_all_test();

}