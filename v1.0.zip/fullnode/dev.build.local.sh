

RUSTFLAGS="-C target-feature=-crt-static" RUST_BACKTRACE="full" cargo build --release --bin fullnode --no-default-features --features "db-leveldb-sys"
cp ./target/release/fullnode   ~/桌面/hacash_node/hacash_fullnode_ubuntu_2










