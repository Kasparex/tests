use std::any::*;

use dyn_clone::*;

include!{"ir.rs"}
include!{"vm.rs"}

