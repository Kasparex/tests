// Latest
combi_struct!{ ChainStatus, 
	root_height:  BlockHeight    // state write on disk height
	last_height:  BlockHeight    // the latest block height
}
