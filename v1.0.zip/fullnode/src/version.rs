

const HACASH_NODE_VERSION: &str    = "0.2.12";
const HACASH_NODE_BUILD_TIME: &str = "2025/03/11(1)";
#[allow(unused)]
const HACASH_STATE_DB_UPDT: u32    = 2;




