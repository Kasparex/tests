
/*
* main fullnode
*/
include!{"./bin/fullnode.rs"}


