
/*
impl MemTxPool {
    pub const GROUP: usize = 2;

    pub const NORMAL: usize = 0;
    pub const DIAMINT: usize = 1;

    pub const TIPS: [&str; Self::GROUP] = [
        "normal", 
        "diamond mint"
    ];

}
*/


///////////////////

