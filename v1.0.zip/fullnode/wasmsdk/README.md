
```sh

## dependencies
rustup target add wasm32-unknown-unknown
cargo install wasm-snip
cargo install wasm-opt
sudo apt install wabt

## build
./build.sh


```
