
pub const TXGID_NORMAL:  usize = 0;
pub const TXGID_DIAMINT: usize = 1;



