
pub const CALL_EXTEND_ENV_DEFS: [&'static str; 3] = [
    "_unknown_",
    "block_height",
    "tx_main_address"
];


pub const CALL_EXTEND_FUNC_DEFS: [&'static str; 2] = [
    "_unknown_",
    "check_signature"
];



